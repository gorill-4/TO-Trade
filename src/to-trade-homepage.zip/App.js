
import React from 'react';
import TradingViewWidget from './TradingViewWidget';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>TO Trade</h1>
        <TradingViewWidget />
        <div className="forecast-box">
          <button>📈 UP</button>
          <button>📉 DOWN</button>
        </div>
      </header>
    </div>
  );
}

export default App;
